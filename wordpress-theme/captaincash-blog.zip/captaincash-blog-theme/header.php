<?php
/**
 * Captain Cash Blog — header.php
 * Matches captaincash.ca header exactly
 * Called by get_header()
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a href="#main" class="skip-link"><?php _e( 'Skip to content', 'captaincash-blog' ); ?></a>

<header class="site-header site-header--dark" id="site-header">
  <div class="container header-inner">
    <a href="<?php echo esc_url( CC_SITE_URL ); ?>" class="site-logo-img">
      <img src="<?php echo esc_url( CC_SITE_URL ); ?>/images/mascot/sprites/logo-lockup-small.webp" alt="Captain Cash — Here to save the day" width="192" height="48" loading="eager">
    </a>
    <nav class="nav-links" aria-label="Main navigation">

      <!-- Products dropdown -->
      <div class="nav-item nav-item--dropdown">
        <button class="nav-dropdown-trigger" aria-expanded="false" aria-haspopup="true">
          Products
          <svg class="nav-chev" width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M2 4l4 4 4-4"/></svg>
        </button>
        <div class="nav-dropdown" role="menu">
          <a href="<?php echo esc_url( CC_SITE_URL ); ?>/claim-your-cash/" class="nav-drop-item" role="menuitem">
            <span class="nav-drop-icon nav-drop-icon--red" aria-hidden="true">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
            </span>
            <span class="nav-drop-text">
              <strong>Get a loan</strong>
              <span>$500–$1,000, same business day</span>
            </span>
          </a>
          <a href="<?php echo esc_url( CC_SITE_URL ); ?>/renew-your-loan/" class="nav-drop-item" role="menuitem">
            <span class="nav-drop-icon nav-drop-icon--amber" aria-hidden="true">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>
            </span>
            <span class="nav-drop-text">
              <strong>Renew your loan</strong>
              <span>Fast track for returning customers</span>
            </span>
          </a>
          <a href="/online-payment/" class="nav-drop-item" role="menuitem">
            <span class="nav-drop-icon nav-drop-icon--blue" aria-hidden="true">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
            </span>
            <span class="nav-drop-text">
              <strong>Online payment</strong>
              <span>Pay or manage your existing loan</span>
            </span>
          </a>
          <div class="nav-drop-sep" aria-hidden="true"></div>
          
        </div>
      </div>

      <!-- Learn dropdown -->
      <div class="nav-item nav-item--dropdown">
        <button class="nav-dropdown-trigger" aria-expanded="false" aria-haspopup="true">
          Learn
          <svg class="nav-chev" width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M2 4l4 4 4-4"/></svg>
        </button>
        <div class="nav-dropdown" role="menu">
          <a href="<?php echo esc_url( CC_SITE_URL ); ?>/how-does-it-work/" class="nav-drop-item" role="menuitem">
            <span class="nav-drop-icon nav-drop-icon--blue" aria-hidden="true">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            </span>
            <span class="nav-drop-text">
              <strong>How it works</strong>
              <span>Apply, approve, get funded</span>
            </span>
          </a>
          <a href="<?php echo esc_url( CC_SITE_URL ); ?>/support/" class="nav-drop-item" role="menuitem">
            <span class="nav-drop-icon nav-drop-icon--green" aria-hidden="true">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
            </span>
            <span class="nav-drop-text">
              <strong>FAQ</strong>
              <span>Common questions answered</span>
            </span>
          </a>
          <a href="<?php echo esc_url( CC_SITE_URL ); ?>/about-us/" class="nav-drop-item" role="menuitem">
            <span class="nav-drop-icon nav-drop-icon--red" aria-hidden="true">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>
            </span>
            <span class="nav-drop-text">
              <strong>About Captain Cash</strong>
              <span>Canadian lender since 2015</span>
            </span>
          </a>
          <a href="<?php echo esc_url( CC_SITE_URL ); ?>/testimonials/" class="nav-drop-item" role="menuitem">
            <span class="nav-drop-icon nav-drop-icon--amber" aria-hidden="true">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
            </span>
            <span class="nav-drop-text">
              <strong>Reviews</strong>
              <span>What customers say</span>
            </span>
          </a>
          <div class="nav-drop-sep" aria-hidden="true"></div>
          <a href="<?php echo esc_url( CC_BLOG_URL ); ?>/" class="nav-drop-item" role="menuitem">
            <span class="nav-drop-icon nav-drop-icon--amber" aria-hidden="true">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 3h6a4 4 0 014 4v14a3 3 0 00-3-3H2z"/><path d="M22 3h-6a4 4 0 00-4 4v14a3 3 0 013-3h7z"/></svg>
            </span>
            <span class="nav-drop-text">
              <strong>Blog</strong>
              <span>Tips for Canadian borrowers</span>
            </span>
          </a>
        </div>
      </div>

      <!-- Direct links -->
      <a href="<?php echo esc_url( CC_SITE_URL ); ?>/contact-us/" class="nav-link-plain">Contact</a>

    </nav>
    <div class="nav-cta">
      <a href="tel:18882261026" class="nav-phone nav-phone--dark" aria-label="Call us at 1-888-226-1026">
        <span class="nav-phone-icon" aria-hidden="true">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#e82020" stroke-width="2.5"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 11a19.79 19.79 0 01-3.07-8.67A2 2 0 012 .18h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
        </span>
        <span class="nav-phone-text">
          <span class="nav-phone-label">Call us</span>
          <span class="nav-phone-num">1-888-226-1026</span>
        </span>
      </a>
      <a href="<?php echo esc_url( CC_SITE_URL ); ?>/claim-your-cash/" class="btn-header-red">Get a loan</a>
      <a href="<?php echo esc_url( CC_SITE_URL ); ?>/renew-your-loan/" class="btn-header-amber">Renew</a>
    </div>
    <button class="hamburger hamburger--dark" aria-label="Open menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>

<!-- ═══════════════════════════════════════
     TRUST BAR
═══════════════════════════════════════ -->
<div class="trust-bar" role="complementary" aria-label="Trust credentials">
  <div class="container trust-bar-inner">
    <div class="trust-bar-item">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      <span>CLA member since 2015</span>
    </div>
    <div class="trust-bar-divider" aria-hidden="true"></div>
    <div class="trust-bar-item">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
      <span>SSL encrypted</span>
    </div>
    <div class="trust-bar-divider" aria-hidden="true"></div>
    <div class="trust-bar-item">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
      <span>12,000+ Canadians served</span>
    </div>
    <div class="trust-bar-divider" aria-hidden="true"></div>
    <div class="trust-bar-item">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
      <span>Provincially licensed</span>
    </div>
    <div class="trust-bar-divider" aria-hidden="true"></div>
    <div class="trust-bar-item">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
      <span>Same-day e-Transfer</span>
    </div>
    <div class="trust-bar-divider" aria-hidden="true"></div>
    <div class="trust-bar-item">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
      <span>APR 23% — transparent</span>
    </div>
  </div>
</div>

<main>
