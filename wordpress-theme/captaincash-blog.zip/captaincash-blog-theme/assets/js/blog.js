/**
 * Captain Cash Blog — blog.js
 * Vanilla JS only — no jQuery, no frameworks
 * Handles: sticky header, nav dropdowns, social share copy, scroll animations
 */

(function () {
  'use strict';

  // ── Sticky header scroll state ──────────────────────────────────
  var header = document.getElementById('site-header');
  if (header) {
    window.addEventListener('scroll', function () {
      header.classList.toggle('site-header--scrolled', window.scrollY > 60);
    }, { passive: true });
  }

  // ── Nav dropdown toggles ────────────────────────────────────────
  var triggers = document.querySelectorAll('.nav-dropdown-trigger');

  function closeAllDropdowns() {
    triggers.forEach(function (t) {
      t.setAttribute('aria-expanded', 'false');
      var dd = t.nextElementSibling;
      if (dd) dd.classList.remove('nav-dropdown--open');
    });
  }

  triggers.forEach(function (trigger) {
    trigger.addEventListener('click', function (e) {
      e.stopPropagation();
      var isOpen = trigger.getAttribute('aria-expanded') === 'true';
      closeAllDropdowns();
      if (!isOpen) {
        trigger.setAttribute('aria-expanded', 'true');
        var dd = trigger.nextElementSibling;
        if (dd) dd.classList.add('nav-dropdown--open');
      }
    });
  });

  document.addEventListener('click', closeAllDropdowns);
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeAllDropdowns();
  });

  // ── Copy URL button ─────────────────────────────────────────────
  var copyBtn = document.getElementById('copy-url-btn');
  if (copyBtn) {
    copyBtn.addEventListener('click', function () {
      var url = copyBtn.dataset.url || window.location.href;
      if (navigator.clipboard) {
        navigator.clipboard.writeText(url).then(function () {
          copyBtn.innerHTML =
            '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg> Copied!';
          copyBtn.style.color = '#16a34a';
          copyBtn.style.borderColor = 'rgba(22,163,74,0.4)';
          setTimeout(function () {
            copyBtn.innerHTML =
              '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg> Copy link';
            copyBtn.style.color = '';
            copyBtn.style.borderColor = '';
          }, 2000);
        });
      } else {
        // Fallback
        var ta = document.createElement('textarea');
        ta.value = url;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        copyBtn.textContent = 'Copied!';
        setTimeout(function () { copyBtn.textContent = 'Copy link'; }, 2000);
      }
    });
  }

  // ── Smooth scroll for anchor links ──────────────────────────────
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var target = document.querySelector(a.getAttribute('href'));
      if (target) {
        e.preventDefault();
        var headerHeight = header ? header.offsetHeight : 0;
        var top = target.getBoundingClientRect().top + window.scrollY - headerHeight - 20;
        window.scrollTo({ top: top, behavior: 'smooth' });
      }
    });
  });

  // ── Lazy load images (polyfill for older browsers) ──────────────
  if ('loading' in HTMLImageElement.prototype) {
    // Native lazy loading supported — nothing to do
  } else {
    // Simple IntersectionObserver polyfill
    var lazyImages = document.querySelectorAll('img[loading="lazy"]');
    if ('IntersectionObserver' in window) {
      var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            var img = entry.target;
            if (img.dataset.src) img.src = img.dataset.src;
            observer.unobserve(img);
          }
        });
      }, { rootMargin: '200px 0px' });
      lazyImages.forEach(function (img) { observer.observe(img); });
    }
  }

  // ── Reading progress bar (single posts) ─────────────────────────
  var progressBar = document.getElementById('reading-progress');
  if (progressBar) {
    window.addEventListener('scroll', function () {
      var doc = document.documentElement;
      var scrolled = (doc.scrollTop || document.body.scrollTop);
      var total = doc.scrollHeight - doc.clientHeight;
      var pct = total > 0 ? Math.min(100, (scrolled / total) * 100) : 0;
      progressBar.style.width = pct + '%';
    }, { passive: true });
  }

  // ── Add reading progress bar to single posts ─────────────────────
  if (document.body.classList.contains('single-post')) {
    var bar = document.createElement('div');
    bar.id = 'reading-progress';
    bar.setAttribute('role', 'progressbar');
    bar.setAttribute('aria-label', 'Reading progress');
    bar.setAttribute('aria-valuenow', '0');
    bar.setAttribute('aria-valuemin', '0');
    bar.setAttribute('aria-valuemax', '100');
    bar.style.cssText = 'position:fixed;top:0;left:0;width:0%;height:3px;background:linear-gradient(90deg,#e82020,#ff6a4d);z-index:9999;transition:width 0.1s linear;pointer-events:none;';
    document.body.prepend(bar);

    // Re-initialize the scroll listener for this bar
    window.addEventListener('scroll', function () {
      var doc = document.documentElement;
      var scrolled = doc.scrollTop || document.body.scrollTop;
      var total = doc.scrollHeight - doc.clientHeight;
      var pct = total > 0 ? Math.min(100, (scrolled / total) * 100) : 0;
      bar.style.width = pct + '%';
      bar.setAttribute('aria-valuenow', Math.round(pct));
    }, { passive: true });
  }

  // ── Social share open in popup ───────────────────────────────────
  document.querySelectorAll('.social-share-btn[href]').forEach(function (btn) {
    btn.addEventListener('click', function (e) {
      e.preventDefault();
      var url = btn.getAttribute('href');
      var w = 600, h = 400;
      var left = (window.screen.width - w) / 2;
      var top = (window.screen.height - h) / 2;
      window.open(url, 'share', 'width=' + w + ',height=' + h + ',left=' + left + ',top=' + top + ',toolbar=0,status=0');
    });
  });

  // ── Mobile hamburger (if theme adds one) ─────────────────────────
  var hamburger = document.querySelector('.nav-hamburger');
  var navLinks  = document.querySelector('.nav-links');
  if (hamburger && navLinks) {
    hamburger.addEventListener('click', function () {
      var expanded = hamburger.getAttribute('aria-expanded') === 'true';
      hamburger.setAttribute('aria-expanded', String(!expanded));
      navLinks.classList.toggle('nav-links--open', !expanded);
    });
  }

})();
