<?php
/**
 * Captain Cash Blog — template-parts/content-card.php
 * Reusable post card partial
 * Usage: get_template_part( 'template-parts/content', 'card' )
 *
 * @var bool   $cc_featured  Whether this is the featured (first) card
 * @var string $cc_size      Thumbnail size ('cc-card' or 'cc-featured')
 */

$cc_featured = $cc_featured ?? false;
$cc_size     = $cc_size ?? 'cc-card';
$cats        = get_the_category();
$cat         = $cats ? $cats[0] : null;
$read_time   = cc_blog_read_time();
$card_class  = $cc_featured ? 'post-card post-card--featured' : 'post-card';
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( $card_class ); ?>>

  <div class="post-card-thumb">
    <?php if ( has_post_thumbnail() ) : ?>
      <a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
        <?php the_post_thumbnail( $cc_size, [
          'alt'          => esc_attr( get_the_title() ),
          'loading'      => $cc_featured ? 'eager' : 'lazy',
          'fetchpriority'=> $cc_featured ? 'high' : 'auto',
          'decoding'     => $cc_featured ? 'sync' : 'async',
        ] ); ?>
      </a>
    <?php else : ?>
      <a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
        <div class="post-card-thumb-placeholder">
          <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.15)" stroke-width="1.5" aria-hidden="true">
            <path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/>
          </svg>
        </div>
      </a>
    <?php endif; ?>
  </div>

  <div class="post-card-body">
    <div class="post-card-meta">
      <?php if ( $cat ) : ?>
        <a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>" class="post-card-cat">
          <?php echo esc_html( $cat->name ); ?>
        </a>
      <?php endif; ?>
      <span class="post-card-date">
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
          <rect x="3" y="4" width="18" height="18" rx="2"/>
          <line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/>
          <line x1="3" y1="10" x2="21" y2="10"/>
        </svg>
        <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
          <?php echo get_the_date( 'M j, Y' ); ?>
        </time>
      </span>
      <span class="post-card-read-time"><?php echo esc_html( $read_time ); ?></span>
    </div>

    <a href="<?php the_permalink(); ?>" class="post-card-title">
      <?php the_title(); ?>
    </a>

    <p class="post-card-excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>

    <div class="post-card-footer">
      <div class="post-card-author">
        <?php echo get_avatar( get_the_author_meta( 'ID' ), 22, '', esc_attr( get_the_author() ) ); ?>
        <span class="post-card-author-name"><?php the_author(); ?></span>
      </div>
      <a href="<?php the_permalink(); ?>"
         class="post-card-read-link"
         aria-label="<?php echo esc_attr( sprintf( __( 'Read: %s', 'captaincash-blog' ), get_the_title() ) ); ?>">
        <?php _e( 'Read', 'captaincash-blog' ); ?>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
          <path d="M5 12h14M12 5l7 7-7 7"/>
        </svg>
      </a>
    </div>
  </div>

</article>
