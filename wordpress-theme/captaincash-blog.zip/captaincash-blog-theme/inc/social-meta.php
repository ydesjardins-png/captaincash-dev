<?php
/**
 * Captain Cash Blog — Social meta tags
 * Open Graph + Twitter Card for every template type
 * Designed for maximum richness on Facebook, X, LinkedIn, iMessage, WhatsApp
 */

defined( 'ABSPATH' ) || exit;

// Remove default WordPress title from head (we control it)
remove_action( 'wp_head', '_wp_render_title_tag', 1 );

function cc_blog_social_meta() {
    // Fallback OG image — blog-specific banner
    $default_og  = CC_SITE_URL . '/images/og-image.jpg';
    $site_name   = 'Captain Cash';
    $locale      = 'en_CA';

    // ── Determine page-specific values ───────────────────────────
    if ( is_singular( 'post' ) ) {
        $title       = get_the_title() . ' | Captain Cash Blog';
        $description = wp_strip_all_tags( get_the_excerpt() );
        $url         = get_permalink();
        $type        = 'article';
        $image       = get_the_post_thumbnail_url( get_the_ID(), 'cc-featured' ) ?: $default_og;
        $image_w     = get_the_post_thumbnail_url( get_the_ID(), 'cc-featured' ) ? 1200 : 1200;
        $image_h     = get_the_post_thumbnail_url( get_the_ID(), 'cc-featured' ) ? 675  : 630;
        $author      = get_the_author();
        $pub_time    = get_the_date( 'c' );
        $mod_time    = get_the_modified_date( 'c' );
        $cats        = get_the_category();
        $section     = $cats ? $cats[0]->name : 'Personal Finance';
        $tags        = implode( ', ', wp_list_pluck( (array) get_the_tags(), 'name' ) );
    } elseif ( is_category() ) {
        $title       = single_cat_title( '', false ) . ' — Captain Cash Blog';
        $description = category_description() ?: 'Expert articles on ' . single_cat_title( '', false ) . ' from the Captain Cash blog.';
        $url         = get_category_link( get_queried_object_id() );
        $type        = 'website';
        $image       = $default_og;
        $image_w     = 1200; $image_h = 630;
    } elseif ( is_search() ) {
        $title       = 'Search results for "' . get_search_query() . '" | Captain Cash Blog';
        $description = 'Search the Captain Cash blog for articles on Canadian loans and personal finance.';
        $url         = get_search_link();
        $type        = 'website';
        $image       = $default_og;
        $image_w     = 1200; $image_h = 630;
    } elseif ( is_author() ) {
        $author_obj  = get_queried_object();
        $title       = 'Articles by ' . $author_obj->display_name . ' | Captain Cash Blog';
        $description = $author_obj->description ?: 'Read articles by ' . $author_obj->display_name . ' on the Captain Cash blog.';
        $url         = get_author_posts_url( $author_obj->ID );
        $type        = 'profile';
        $image       = get_avatar_url( $author_obj->ID, [ 'size' => 400 ] ) ?: $default_og;
        $image_w     = 400; $image_h = 400;
    } else {
        // Blog index
        $title       = 'Blog — Canadian Loans & Personal Finance | Captain Cash';
        $description = 'Expert guides on online loans, no-credit-check borrowing, and personal finance for Canadians. Trusted since 2015.';
        $url         = CC_BLOG_URL . '/';
        $type        = 'website';
        $image       = $default_og;
        $image_w     = 1200; $image_h = 630;
    }

    // Trim description
    $description = mb_strimwidth( wp_strip_all_tags( $description ), 0, 155, '…' );

    ?>
    <!-- Open Graph / Facebook / LinkedIn / iMessage -->
    <meta property="og:site_name"   content="<?php echo esc_attr( $site_name ); ?>">
    <meta property="og:locale"      content="<?php echo esc_attr( $locale ); ?>">
    <meta property="og:type"        content="<?php echo esc_attr( $type ); ?>">
    <meta property="og:url"         content="<?php echo esc_url( $url ); ?>">
    <meta property="og:title"       content="<?php echo esc_attr( $title ); ?>">
    <meta property="og:description" content="<?php echo esc_attr( $description ); ?>">
    <meta property="og:image"       content="<?php echo esc_url( $image ); ?>">
    <meta property="og:image:width"  content="<?php echo esc_attr( $image_w ); ?>">
    <meta property="og:image:height" content="<?php echo esc_attr( $image_h ); ?>">
    <meta property="og:image:alt"    content="<?php echo esc_attr( $title ); ?>">
    <?php if ( $type === 'article' ) : ?>
    <meta property="article:published_time"  content="<?php echo esc_attr( $pub_time ); ?>">
    <meta property="article:modified_time"   content="<?php echo esc_attr( $mod_time ); ?>">
    <meta property="article:author"          content="<?php echo esc_attr( $author ?? '' ); ?>">
    <meta property="article:section"         content="<?php echo esc_attr( $section ?? '' ); ?>">
    <?php if ( ! empty( $tags ) ) : ?>
    <meta property="article:tag"             content="<?php echo esc_attr( $tags ); ?>">
    <?php endif; ?>
    <?php endif; ?>

    <!-- Twitter / X Card -->
    <meta name="twitter:card"        content="summary_large_image">
    <meta name="twitter:site"        content="@captaincash_ca">
    <meta name="twitter:title"       content="<?php echo esc_attr( $title ); ?>">
    <meta name="twitter:description" content="<?php echo esc_attr( $description ); ?>">
    <meta name="twitter:image"       content="<?php echo esc_url( $image ); ?>">
    <meta name="twitter:image:alt"   content="<?php echo esc_attr( $title ); ?>">

    <!-- Canonical -->
    <link rel="canonical" href="<?php echo esc_url( $url ); ?>">

    <!-- Description (standard) -->
    <meta name="description" content="<?php echo esc_attr( $description ); ?>">

    <!-- Apple touch icon (inherits from main site) -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url( CC_SITE_URL ); ?>/images/apple-touch-icon.png">
    <link rel="icon" type="image/x-icon" href="<?php echo esc_url( CC_SITE_URL ); ?>/favicon.ico">

    <!-- lang -->
    <?php
}
add_action( 'wp_head', 'cc_blog_social_meta', 2 );


// ── Robots meta ───────────────────────────────────────────────────
function cc_blog_robots_meta() {
    // Noindex paginated archives after page 1
    if ( is_paged() && get_query_var( 'paged' ) > 1 ) {
        echo '<meta name="robots" content="noindex, follow">' . "\n";
    } elseif ( is_search() || is_404() ) {
        echo '<meta name="robots" content="noindex, nofollow">' . "\n";
    } else {
        echo '<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">' . "\n";
    }
}
add_action( 'wp_head', 'cc_blog_robots_meta', 3 );
