<?php
/**
 * Captain Cash Blog — Schema injection
 * Outputs JSON-LD structured data for every template type
 * YMYL-compliant: Organization, WebSite, Blog, BlogPosting, Person, BreadcrumbList
 */

defined( 'ABSPATH' ) || exit;

function cc_blog_schema() {
    $schemas = [];

    // ── Organization (on every page) ──────────────────────────────
    $org = [
        '@type'           => 'Organization',
        '@id'             => CC_ORG_ID,
        'name'            => 'Captain Cash',
        'url'             => CC_SITE_URL,
        'logo'            => [
            '@type'       => 'ImageObject',
            'url'         => CC_SITE_URL . '/images/mascot/sprites/logo-lockup-small.webp',
            'width'       => 192,
            'height'      => 48,
        ],
        'telephone'       => CC_PHONE,
        'email'           => CC_EMAIL,
        'address'         => [
            '@type'           => 'PostalAddress',
            'streetAddress'   => '1701 Hollis Street W. Suite 800',
            'addressLocality' => 'Halifax',
            'addressRegion'   => 'NS',
            'postalCode'      => 'B3J 2T9',
            'addressCountry'  => 'CA',
        ],
        'foundingDate'    => '2015',
        'numberOfEmployees' => 50,
        'memberOf'        => [
            '@type' => 'Organization',
            'name'  => 'Canadian Lenders Association',
        ],
        'sameAs'          => [
            'https://www.facebook.com/captaincash',
            'https://twitter.com/captaincash_ca',
        ],
    ];

    // ── WebSite ───────────────────────────────────────────────────
    $website = [
        '@type'     => 'WebSite',
        '@id'       => CC_SITE_URL . '/#website',
        'url'       => CC_SITE_URL,
        'name'      => 'Captain Cash',
        'publisher' => [ '@id' => CC_ORG_ID ],
        'potentialAction' => [
            '@type'       => 'SearchAction',
            'target'      => [
                '@type'       => 'EntryPoint',
                'urlTemplate' => CC_BLOG_URL . '/?s={search_term_string}',
            ],
            'query-input' => 'required name=search_term_string',
        ],
    ];

    // ── Blog (index page) ─────────────────────────────────────────
    if ( is_home() || is_front_page() ) {
        $blog = [
            '@type'       => 'Blog',
            '@id'         => CC_BLOG_URL . '/#blog',
            'url'         => CC_BLOG_URL . '/',
            'name'        => 'Captain Cash Blog — Canadian Lending & Personal Finance',
            'description' => 'Expert guides on online loans, personal finance, and Canadian consumer lending.',
            'publisher'   => [ '@id' => CC_ORG_ID ],
            'inLanguage'  => 'en-CA',
        ];
        $schemas[] = [ '@context' => 'https://schema.org', '@graph' => [ $org, $website, $blog ] ];
    }

    // ── Single post (BlogPosting + Person + BreadcrumbList) ───────
    elseif ( is_singular( 'post' ) ) {
        $post      = get_post();
        $author_id = $post->post_author;
        $author_name = get_the_author_meta( 'display_name', $author_id );
        $credentials = get_user_meta( $author_id, 'credentials', true ) ?: 'Financial Content Writer';
        $reviewer    = get_user_meta( $author_id, 'reviewer_name', true );
        $linkedin    = get_user_meta( $author_id, 'linkedin_url', true );
        $avatar_url  = get_avatar_url( $author_id, [ 'size' => 200 ] );
        $thumb_url   = get_the_post_thumbnail_url( $post->ID, 'cc-featured' );
        $excerpt     = wp_strip_all_tags( get_the_excerpt() );
        $word_count  = str_word_count( wp_strip_all_tags( $post->post_content ) );
        $cats        = get_the_category( $post->ID );
        $cat_name    = $cats ? $cats[0]->name : 'Personal Finance';

        // Author Person entity
        $author_entity = [
            '@type'       => 'Person',
            '@id'         => get_author_posts_url( $author_id ) . '#person',
            'name'        => $author_name,
            'jobTitle'    => $credentials,
            'worksFor'    => [ '@id' => CC_ORG_ID ],
            'url'         => get_author_posts_url( $author_id ),
        ];
        if ( $avatar_url )  $author_entity['image'] = [ '@type' => 'ImageObject', 'url' => $avatar_url ];
        if ( $linkedin )    $author_entity['sameAs'] = [ $linkedin ];

        // BlogPosting
        $article = [
            '@type'            => 'BlogPosting',
            '@id'              => get_permalink() . '#article',
            'headline'         => get_the_title(),
            'description'      => $excerpt,
            'url'              => get_permalink(),
            'datePublished'    => get_the_date( 'c' ),
            'dateModified'     => get_the_modified_date( 'c' ),
            'author'           => [ '@id' => get_author_posts_url( $author_id ) . '#person' ],
            'publisher'        => [ '@id' => CC_ORG_ID ],
            'isPartOf'         => [ '@id' => CC_BLOG_URL . '/#blog' ],
            'articleSection'   => $cat_name,
            'wordCount'        => $word_count,
            'inLanguage'       => 'en-CA',
            'about'            => [ '@type' => 'Thing', 'name' => $cat_name ],
        ];
        if ( $thumb_url ) {
            $article['image'] = [
                '@type'  => 'ImageObject',
                'url'    => $thumb_url,
                'width'  => 1200,
                'height' => 675,
            ];
        }
        if ( $reviewer ) {
            $article['reviewedBy'] = [
                '@type'    => 'Person',
                'name'     => $reviewer,
                'worksFor' => [ '@id' => CC_ORG_ID ],
            ];
        }

        // BreadcrumbList
        $breadcrumb_items = [
            [ '@type' => 'ListItem', 'position' => 1, 'name' => 'Home',   'item' => CC_SITE_URL ],
            [ '@type' => 'ListItem', 'position' => 2, 'name' => 'Blog',   'item' => CC_BLOG_URL . '/' ],
        ];
        if ( $cats ) {
            $breadcrumb_items[] = [
                '@type'    => 'ListItem',
                'position' => 3,
                'name'     => $cats[0]->name,
                'item'     => get_category_link( $cats[0]->term_id ),
            ];
            $breadcrumb_items[] = [
                '@type'    => 'ListItem',
                'position' => 4,
                'name'     => get_the_title(),
                'item'     => get_permalink(),
            ];
        } else {
            $breadcrumb_items[] = [
                '@type'    => 'ListItem',
                'position' => 3,
                'name'     => get_the_title(),
                'item'     => get_permalink(),
            ];
        }

        $breadcrumb = [
            '@type'           => 'BreadcrumbList',
            'itemListElement' => $breadcrumb_items,
        ];

        $schemas[] = [ '@context' => 'https://schema.org', '@graph' => [ $org, $website, $author_entity, $article, $breadcrumb ] ];
    }

    // ── Archive / category pages ──────────────────────────────────
    elseif ( is_category() || is_tag() || is_archive() ) {
        $archive = [
            '@type'       => 'CollectionPage',
            'url'         => get_pagenum_link(),
            'name'        => wp_strip_all_tags( get_the_archive_title() ),
            'description' => get_the_archive_description(),
            'publisher'   => [ '@id' => CC_ORG_ID ],
            'inLanguage'  => 'en-CA',
        ];
        $breadcrumb = [
            '@type' => 'BreadcrumbList',
            'itemListElement' => [
                [ '@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => CC_SITE_URL ],
                [ '@type' => 'ListItem', 'position' => 2, 'name' => 'Blog', 'item' => CC_BLOG_URL . '/' ],
                [ '@type' => 'ListItem', 'position' => 3, 'name' => wp_strip_all_tags( get_the_archive_title() ), 'item' => get_pagenum_link() ],
            ],
        ];
        $schemas[] = [ '@context' => 'https://schema.org', '@graph' => [ $org, $website, $archive, $breadcrumb ] ];
    }

    // ── Default fallback (every other page) ──────────────────────
    else {
        $schemas[] = [ '@context' => 'https://schema.org', '@graph' => [ $org, $website ] ];
    }

    // Output
    foreach ( $schemas as $schema ) {
        echo "\n" . '<script type="application/ld+json">' . "\n";
        echo wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
        echo "\n" . '</script>' . "\n";
    }
}
add_action( 'wp_head', 'cc_blog_schema', 5 );
