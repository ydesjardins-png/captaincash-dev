<?php
/**
 * Captain Cash Blog — Speed optimizations
 * Resource hints, lazy loading, critical CSS, DNS prefetch
 */

defined( 'ABSPATH' ) || exit;

// ── Resource hints in <head> ─────────────────────────────────────
function cc_blog_resource_hints() {
    // Preconnect to self for font files
    echo '<link rel="preconnect" href="' . esc_url( CC_BLOG_URL ) . '">' . "\n";

    // If using Google Fonts as fallback
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";

    // DNS prefetch for social share targets
    echo '<link rel="dns-prefetch" href="https://www.facebook.com">' . "\n";
    echo '<link rel="dns-prefetch" href="https://twitter.com">' . "\n";
    echo '<link rel="dns-prefetch" href="https://www.linkedin.com">' . "\n";

    // Preload blog CSS (critical)
    echo '<link rel="preload" href="' . esc_url( get_template_directory_uri() . '/assets/css/blog.css' ) . '" as="style">' . "\n";

    // Preload Inter font weights most used
    echo '<link rel="preload" href="' . esc_url( get_template_directory_uri() . '/assets/css/inter-400.woff2' ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
    echo '<link rel="preload" href="' . esc_url( get_template_directory_uri() . '/assets/css/inter-700.woff2' ) . '" as="font" type="font/woff2" crossorigin>' . "\n";

    // Preload LCP image on single posts
    if ( is_singular( 'post' ) && has_post_thumbnail() ) {
        $thumb = wp_get_attachment_image_src( get_post_thumbnail_id(), 'cc-featured' );
        if ( $thumb ) {
            echo '<link rel="preload" href="' . esc_url( $thumb[0] ) . '" as="image" fetchpriority="high">' . "\n";
        }
    }
}
add_action( 'wp_head', 'cc_blog_resource_hints', 1 );


// ── Add fetchpriority=high to first post thumbnail on index ──────
function cc_blog_lcp_fetchpriority( $attr, $attachment, $size ) {
    static $count = 0;
    $count++;
    // First image on the page gets high priority
    if ( $count === 1 && ( is_home() || is_front_page() ) ) {
        $attr['fetchpriority'] = 'high';
        $attr['loading'] = 'eager';
    } else {
        $attr['loading'] = 'lazy';
        $attr['decoding'] = 'async';
    }
    return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'cc_blog_lcp_fetchpriority', 10, 3 );


// ── Defer all non-critical scripts ───────────────────────────────
function cc_blog_defer_scripts( $tag, $handle, $src ) {
    // Never defer admin bar or login scripts
    if ( is_admin() || $handle === 'wp-embed' ) return $tag;

    // Our theme script gets defer (set in wp_enqueue_script with in_footer=true)
    // Force defer on any other scripts that might be enqueued
    $no_defer = [ 'jquery', 'wp-embed' ];
    if ( in_array( $handle, $no_defer ) ) return $tag;

    if ( str_contains( $tag, ' defer' ) || str_contains( $tag, ' async' ) ) return $tag;

    return str_replace( ' src=', ' defer src=', $tag );
}
add_filter( 'script_loader_tag', 'cc_blog_defer_scripts', 10, 3 );


// ── Add width/height to all images (prevent CLS) ─────────────────
add_filter( 'the_content', function( $content ) {
    // WordPress core handles this since 5.5 with wp_lazy_loading_enabled
    return $content;
} );


// ── Disable WordPress emoji scripts ──────────────────────────────
remove_action( 'wp_head',         'print_emoji_detection_script', 7 );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );
remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
remove_filter( 'wp_mail',          'wp_staticize_emoji_for_email' );


// ── Remove oEmbed discovery links ────────────────────────────────
remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
remove_action( 'wp_head', 'wp_oembed_add_host_js' );


// ── Limit post revisions ──────────────────────────────────────────
if ( ! defined( 'WP_POST_REVISIONS' ) ) {
    define( 'WP_POST_REVISIONS', 5 );
}


// ── Add async to Google Fonts if loaded ──────────────────────────
add_filter( 'style_loader_tag', function( $tag, $handle ) {
    if ( $handle === 'cc-inter' ) {
        return str_replace( "rel='stylesheet'", "rel='preload' as='style' onload=\"this.onload=null;this.rel='stylesheet'\"", $tag )
            . "<noscript>" . str_replace( "rel='stylesheet'", "rel='stylesheet'", $tag ) . "</noscript>";
    }
    return $tag;
}, 10, 2 );


// ── Cache buster for theme assets in development ─────────────────
// In production this is the theme version constant — fine as-is


// ── Add Vary: Accept-Encoding header hint ────────────────────────
add_action( 'send_headers', function() {
    if ( ! is_admin() ) {
        header( 'X-Content-Type-Options: nosniff' );
        header( 'X-Frame-Options: SAMEORIGIN' );
        header( 'Referrer-Policy: strict-origin-when-cross-origin' );
    }
} );
