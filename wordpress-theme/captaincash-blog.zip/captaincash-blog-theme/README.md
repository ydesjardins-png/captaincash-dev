# Captain Cash Blog — WordPress Theme

Custom WordPress theme for `captaincash.ca/blog/`. Matches the main site design system exactly.

---

## Requirements

- WordPress 6.4+
- PHP 8.1+
- No required plugins (theme is fully self-contained)
- Recommended plugins: **Yoast SEO** or **RankMath** (schema/sitemap), **WP Super Cache** or **LiteSpeed Cache**

---

## Installation

### 1. Upload the theme

1. Log in to WordPress admin → **Appearance → Themes → Add New → Upload Theme**
2. Upload `captaincash-blog.zip`
3. Click **Activate**

### 2. Configure WordPress settings

Go to **Settings → Reading**:
- Set **"Your homepage displays"** to **"Your latest posts"**
- This makes `/blog/` serve the post index

Go to **Settings → Permalinks**:
- Select **"Post name"** (`/%postname%/`)
- Click **Save Changes**

### 3. Set up your categories

Create categories matching your editorial topics, e.g.:
- Loans & Borrowing
- Personal Finance
- Credit & Debt
- Financial Tips

### 4. Configure author profiles

For each author, go to **Users → Profile** and fill in:
- **Display name** — shown on posts and in schema
- **Biographical Info** — shown in the author bio box
- **Title / Credentials** — e.g. "Financial Journalist", "CFA" (custom field)
- **Fact-checked by** — editor/reviewer name (custom field)
- **LinkedIn URL** — linked in author schema

These fields power the E-E-A-T signals on every post.

### 5. Set featured images

Every post **must** have a featured image at minimum **1200×675px** (16:9).
The theme registers three image sizes:
- `cc-featured` — 1200×675 (single post hero, OG image)
- `cc-card` — 800×450 (post grid cards)
- `cc-thumb` — 120×90 (sidebar recent posts)

---

## Using shortcodes

### CTA banner (insert anywhere in post content)
```
[cc_cta title="Need cash today?" desc="Get $500–$1,000 by Interac e-Transfer." btn="Claim your cash"]
```

### YMYL disclaimer
```
[cc_disclaimer]This article is for informational purposes only.[/cc_disclaimer]
```

### Callout box
```
[callout type="info"]Your content here[/callout]
[callout type="warning"]Warning content[/callout]
[callout type="success"]Success message[/callout]
[callout type="tip"]Pro tip content[/callout]
```

---

## SEO configuration (Yoast / RankMath)

The theme outputs its own:
- `<meta name="description">` — from `cc_blog_social_meta()`
- `<link rel="canonical">` — from `cc_blog_social_meta()`
- `og:*` and `twitter:*` tags — from `cc_blog_social_meta()`
- `application/ld+json` schema — from `cc_blog_schema()`
- `<meta name="robots">` — from `cc_blog_robots_meta()`

**If you install Yoast or RankMath**, disable their social/schema output in their settings to avoid duplication. Keep only their **XML sitemap** and **title tag** features.

---

## Subdirectory setup (captaincash.ca/blog/)

WordPress is installed in `/blog/`. Your Netlify config should proxy `/blog/` to your WordPress host.

The theme constants in `functions.php`:
```php
define( 'CC_SITE_URL',  'https://captaincash.ca' );      // Main site
define( 'CC_BLOG_URL',  'https://captaincash.ca/blog' ); // WordPress subdirectory
```

Update these if your URLs change.

---

## File structure

```
captaincash-blog/
├── style.css                    — Theme declaration
├── functions.php                — Setup, helpers, shortcodes, author fields
├── header.php                   — Exact replica of main site header
├── footer.php                   — Exact replica of main site footer
├── sidebar.php                  — CTA card, categories, recent posts
├── index.php                    — Blog index (featured + grid)
├── single.php                   — Single post (hero, content, author bio, share, related)
├── archive.php                  — Category / tag / author archives
├── search.php                   — Search results
├── page.php                     — Static pages
├── 404.php                      — Not found
├── screenshot.png               — Theme preview
├── inc/
│   ├── schema.php               — JSON-LD structured data (BlogPosting, Person, etc.)
│   ├── social-meta.php          — OG + Twitter Card tags
│   └── speed.php                — Resource hints, lazy load, defer, security headers
├── template-parts/
│   └── content-card.php        — Reusable post card partial
└── assets/
    ├── css/
    │   ├── blog.css             — All blog styles (matches main site design)
    │   ├── inter.css            — @font-face declarations (self-hosted)
    │   ├── inter-400.woff2      — Inter Regular
    │   ├── inter-500.woff2      — Inter Medium
    │   ├── inter-600.woff2      — Inter SemiBold
    │   └── inter-700.woff2      — Inter Bold
    └── js/
        └── blog.js              — Vanilla JS: nav, share, reading progress, lazy load
```

---

## Performance checklist

- [x] Self-hosted Inter font — no Google Fonts request
- [x] Font preloads in `<head>` for 400 and 700 weights
- [x] `defer` on all scripts
- [x] `fetchpriority="high"` on LCP images
- [x] `loading="lazy"` on all below-fold images
- [x] jQuery completely removed
- [x] Block library CSS dequeued
- [x] Emoji scripts removed
- [x] Security headers added (`X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`)
- [x] `noindex` on paginated archives, search, 404

---

## E-E-A-T checklist

- [x] Author name, title/credentials on every post
- [x] Author bio box with photo and description
- [x] Fact-checked/reviewed-by bar (when reviewer set)
- [x] Last-updated date on modified posts
- [x] YMYL disclaimer on every post
- [x] `Person` schema with `worksFor` pointing to Organization
- [x] `BlogPosting` schema with `author`, `reviewedBy`, `dateModified`
- [x] Organization schema on every page (address, phone, founding date, CLA membership)
- [x] Physical address and phone number in footer

---

## Social media checklist

- [x] `og:type = article` on posts, `website` elsewhere
- [x] `og:image` pulls from featured image (fallback to main site OG image)
- [x] `og:image:width/height` declared
- [x] `article:published_time`, `article:modified_time`, `article:author`, `article:section`
- [x] `twitter:card = summary_large_image`
- [x] Facebook, X/Twitter, LinkedIn share buttons on every post
- [x] Share popups (600×400 window) — no page navigation on share
- [x] Copy link button with clipboard API

---

## Go-live steps

1. Update `CC_SITE_URL` and `CC_BLOG_URL` in `functions.php` if needed
2. Update `og:image` fallback URL in `inc/social-meta.php` (`$default_og` variable)
3. Update `twitter:site` handle in `inc/social-meta.php`
4. Submit `captaincash.ca/blog/sitemap_index.xml` (Yoast) to Google Search Console
5. Verify structured data at search.google.com/test/rich-results
