<?php
/**
 * Captain Cash Blog — index.php
 * Blog index page served at /blog/
 * Features: featured first post, card grid, sidebar, pagination
 */

get_header();
?>

<!-- Blog hero -->
<div class="blog-hero">
  <div class="blog-hero-bg" aria-hidden="true">
    <div class="blog-hero-orb"></div>
    <div class="blog-hero-beam"></div>
    <div class="blog-hero-edge"></div>
  </div>
  <div class="container blog-hero-inner">
    <div class="blog-hero-eyebrow"><span></span><?php _e( 'Captain Cash Blog', 'captaincash-blog' ); ?></div>
    <h1><?php _e( 'Loans, money &amp; personal finance', 'captaincash-blog' ); ?></h1>
    <p class="blog-hero-sub"><?php _e( 'Practical guides for Canadians navigating short-term borrowing, budgeting, and financial emergencies.', 'captaincash-blog' ); ?></p>
  </div>
</div>

<div class="blog-wrap">
  <div class="container">
    <div class="blog-inner">

      <!-- Main content -->
      <main id="main" role="main">

        <?php if ( have_posts() ) : ?>

          <div class="post-grid">

            <?php
            $post_count = 0;
            while ( have_posts() ) : the_post();
              $post_count++;
              $cats       = get_the_category();
              $cat        = $cats ? $cats[0] : null;
              $read_time  = cc_blog_read_time();
              $is_featured = ( $post_count === 1 && ! is_paged() );
              $thumb_size  = $is_featured ? 'cc-featured' : 'cc-card';
            ?>

            <article id="post-<?php the_ID(); ?>"
                     <?php post_class( $is_featured ? 'post-card post-card--featured' : 'post-card' ); ?>>

              <!-- Thumbnail -->
              <div class="post-card-thumb">
                <?php if ( has_post_thumbnail() ) : ?>
                  <a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
                    <?php the_post_thumbnail( $thumb_size, [
                      'alt'     => esc_attr( get_the_title() ),
                      'loading' => $is_featured ? 'eager' : 'lazy',
                      $is_featured ? 'fetchpriority' : 'data-x' => $is_featured ? 'high' : '',
                    ] ); ?>
                  </a>
                <?php else : ?>
                  <a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
                    <div class="post-card-thumb-placeholder">
                      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)" stroke-width="1.5" aria-hidden="true"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
                    </div>
                  </a>
                <?php endif; ?>
              </div>

              <!-- Body -->
              <div class="post-card-body">
                <div class="post-card-meta">
                  <?php if ( $cat ) : ?>
                    <a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>"
                       class="post-card-cat"><?php echo esc_html( $cat->name ); ?></a>
                  <?php endif; ?>
                  <span class="post-card-date">
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                    <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo get_the_date( 'M j, Y' ); ?></time>
                  </span>
                  <span class="post-card-read-time"><?php echo esc_html( $read_time ); ?></span>
                </div>

                <a href="<?php the_permalink(); ?>" class="post-card-title">
                  <?php the_title(); ?>
                </a>

                <p class="post-card-excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>

                <div class="post-card-footer">
                  <div class="post-card-author">
                    <?php echo get_avatar( get_the_author_meta( 'ID' ), 22, '', esc_attr( get_the_author() ), [ 'class' => '' ] ); ?>
                    <span class="post-card-author-name"><?php the_author(); ?></span>
                  </div>
                  <a href="<?php the_permalink(); ?>" class="post-card-read-link" aria-label="<?php echo esc_attr( sprintf( __( 'Read: %s', 'captaincash-blog' ), get_the_title() ) ); ?>">
                    <?php _e( 'Read', 'captaincash-blog' ); ?>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                  </a>
                </div>
              </div>

            </article>

            <?php endwhile; ?>

          </div><!-- /post-grid -->

          <!-- Pagination -->
          <div class="blog-pagination" role="navigation" aria-label="<?php esc_attr_e( 'Posts pagination', 'captaincash-blog' ); ?>">
            <?php cc_blog_pagination(); ?>
          </div>

        <?php else : ?>

          <p style="color:var(--gray-500);font-size:1rem;padding:3rem 0;"><?php _e( 'No posts found.', 'captaincash-blog' ); ?></p>

        <?php endif; ?>

      </main><!-- /main -->

      <!-- Sidebar -->
      <?php get_sidebar(); ?>

    </div><!-- /blog-inner -->
  </div><!-- /container -->
</div><!-- /blog-wrap -->

<?php get_footer(); ?>
