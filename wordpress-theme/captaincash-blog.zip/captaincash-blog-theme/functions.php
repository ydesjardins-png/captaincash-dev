<?php
/**
 * Captain Cash Blog — functions.php
 * Theme setup, asset enqueuing, schema injection, social meta, speed optimizations
 */

defined( 'ABSPATH' ) || exit;

// ── Theme constants ──────────────────────────────────────────────
define( 'CC_BLOG_VERSION', '1.0.0' );
define( 'CC_SITE_URL',     'https://captaincash.ca' );
define( 'CC_BLOG_URL',     'https://captaincash.ca/blog' );
define( 'CC_PHONE',        '1-888-226-1026' );
define( 'CC_EMAIL',        'support@captaincash.ca' );
define( 'CC_ADDRESS',      '1701 Hollis Street W. Suite 800, Halifax, NS B3J 2T9' );
define( 'CC_ORG_ID',       'https://captaincash.ca/#organization' );


// ── Theme setup ──────────────────────────────────────────────────
function cc_blog_setup() {
    load_theme_textdomain( 'captaincash-blog', get_template_directory() . '/languages' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'script', 'style' ] );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'editor-styles' );
    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'align-wide' );

    // Register menus
    register_nav_menus( [
        'primary'  => __( 'Primary Navigation', 'captaincash-blog' ),
        'footer'   => __( 'Footer Navigation', 'captaincash-blog' ),
    ] );

    // Custom image sizes
    add_image_size( 'cc-card',     800, 450, true );
    add_image_size( 'cc-featured', 1200, 675, true );
    add_image_size( 'cc-thumb',    120, 90, true );
}
add_action( 'after_setup_theme', 'cc_blog_setup' );


// ── Content width ────────────────────────────────────────────────
function cc_blog_content_width() {
    $GLOBALS['content_width'] = 860;
}
add_action( 'after_setup_theme', 'cc_blog_content_width', 0 );


// ── Enqueue assets ───────────────────────────────────────────────
function cc_blog_scripts() {
    $v = CC_BLOG_VERSION;

    // Inter font — self-hosted (inherits from main site /blog/assets/fonts/)
    wp_enqueue_style(
        'cc-inter',
        get_template_directory_uri() . '/assets/css/inter.css',
        [], $v
    );

    // Main blog stylesheet
    wp_enqueue_style(
        'cc-blog',
        get_template_directory_uri() . '/assets/css/blog.css',
        [ 'cc-inter' ], $v
    );

    // Theme JS — vanilla only, no jQuery dependency
    wp_enqueue_script(
        'cc-blog-js',
        get_template_directory_uri() . '/assets/js/blog.js',
        [], $v, true   // footer = true
    );

    // Pass data to JS
    wp_localize_script( 'cc-blog-js', 'ccBlog', [
        'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
        'siteUrl'  => CC_SITE_URL,
        'blogUrl'  => CC_BLOG_URL,
        'nonce'    => wp_create_nonce( 'cc_blog_nonce' ),
        'postUrl'  => is_singular() ? get_permalink() : '',
        'postTitle'=> is_singular() ? get_the_title() : '',
    ] );
}
add_action( 'wp_enqueue_scripts', 'cc_blog_scripts' );


// ── Remove unnecessary default assets (speed) ───────────────────
function cc_blog_cleanup_head() {
    remove_action( 'wp_head', 'wp_generator' );
    remove_action( 'wp_head', 'wlwmanifest_link' );
    remove_action( 'wp_head', 'rsd_link' );
    remove_action( 'wp_head', 'wp_shortlink_wp_head' );
    remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head' );
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
}
add_action( 'init', 'cc_blog_cleanup_head' );

// Dequeue jQuery from frontend (not needed)
function cc_blog_dequeue_jquery() {
    if ( ! is_admin() ) {
        wp_deregister_script( 'jquery' );
    }
}
add_action( 'wp_enqueue_scripts', 'cc_blog_dequeue_jquery', 99 );

// Disable Gutenberg block library CSS (we style everything ourselves)
add_action( 'wp_enqueue_scripts', function() {
    wp_dequeue_style( 'wp-block-library' );
    wp_dequeue_style( 'wp-block-library-theme' );
    wp_dequeue_style( 'global-styles' );
}, 100 );


// ── Document title separator ─────────────────────────────────────
function cc_blog_title_separator() {
    return '|';
}
add_filter( 'document_title_separator', 'cc_blog_title_separator' );


// ── Custom excerpt length ─────────────────────────────────────────
add_filter( 'excerpt_length', fn() => 25 );
add_filter( 'excerpt_more',   fn() => '…' );


// ── Estimated read time ───────────────────────────────────────────
function cc_blog_read_time( $post_id = null ) {
    $post    = get_post( $post_id );
    $content = wp_strip_all_tags( $post->post_content ?? '' );
    $words   = str_word_count( $content );
    $minutes = max( 1, (int) ceil( $words / 200 ) );
    return sprintf( _n( '%d min read', '%d min read', $minutes, 'captaincash-blog' ), $minutes );
}


// ── Author display name with credentials ─────────────────────────
function cc_blog_author_credentials( $user_id = null ) {
    $user_id = $user_id ?: get_the_author_meta( 'ID' );
    return get_user_meta( $user_id, 'credentials', true ) ?: '';
}


// ── Breadcrumb helper ─────────────────────────────────────────────
function cc_blog_breadcrumbs() {
    $items = [];
    $items[] = '<a href="' . esc_url( CC_SITE_URL ) . '">' . __( 'Home', 'captaincash-blog' ) . '</a>';
    $items[] = '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>';
    $items[] = '<a href="' . esc_url( CC_BLOG_URL ) . '">' . __( 'Blog', 'captaincash-blog' ) . '</a>';

    if ( is_single() ) {
        $cats = get_the_category();
        if ( $cats ) {
            $items[] = '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>';
            $items[] = '<a href="' . esc_url( get_category_link( $cats[0]->term_id ) ) . '">' . esc_html( $cats[0]->name ) . '</a>';
        }
        $items[] = '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>';
        $items[] = '<span>' . get_the_title() . '</span>';
    } elseif ( is_category() ) {
        $items[] = '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>';
        $items[] = '<span>' . single_cat_title( '', false ) . '</span>';
    } elseif ( is_tag() ) {
        $items[] = '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>';
        $items[] = '<span>' . single_tag_title( '', false ) . '</span>';
    } elseif ( is_search() ) {
        $items[] = '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>';
        $items[] = '<span>' . __( 'Search', 'captaincash-blog' ) . '</span>';
    }

    echo '<nav class="single-breadcrumb" aria-label="' . esc_attr__( 'Breadcrumb', 'captaincash-blog' ) . '">';
    echo implode( ' ', $items );
    echo '</nav>';
}


// ── Social share buttons ──────────────────────────────────────────
function cc_blog_social_share() {
    if ( ! is_singular( 'post' ) ) return;

    $url   = urlencode( get_permalink() );
    $title = urlencode( get_the_title() );
    ?>
    <div class="social-share">
        <span class="social-share-label"><?php _e( 'Share:', 'captaincash-blog' ); ?></span>
        <div class="social-share-btns">
            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $url; ?>"
               target="_blank" rel="noopener noreferrer"
               class="social-share-btn social-share-btn--facebook" aria-label="<?php esc_attr_e( 'Share on Facebook', 'captaincash-blog' ); ?>">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg>
                Facebook
            </a>
            <a href="https://twitter.com/intent/tweet?url=<?php echo $url; ?>&text=<?php echo $title; ?>"
               target="_blank" rel="noopener noreferrer"
               class="social-share-btn social-share-btn--x" aria-label="<?php esc_attr_e( 'Share on X', 'captaincash-blog' ); ?>">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
                X / Twitter
            </a>
            <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo $url; ?>&title=<?php echo $title; ?>"
               target="_blank" rel="noopener noreferrer"
               class="social-share-btn social-share-btn--linkedin" aria-label="<?php esc_attr_e( 'Share on LinkedIn', 'captaincash-blog' ); ?>">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"/><circle cx="4" cy="4" r="2"/></svg>
                LinkedIn
            </a>
            <button class="social-share-btn social-share-btn--copy" id="copy-url-btn"
                    data-url="<?php echo esc_attr( get_permalink() ); ?>"
                    aria-label="<?php esc_attr_e( 'Copy link', 'captaincash-blog' ); ?>">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
                <?php _e( 'Copy link', 'captaincash-blog' ); ?>
            </button>
        </div>
    </div>
    <?php
}


// ── Author bio box ────────────────────────────────────────────────
function cc_blog_author_bio() {
    if ( ! is_singular( 'post' ) ) return;

    $author_id   = get_the_author_meta( 'ID' );
    $name        = get_the_author_meta( 'display_name' );
    $title       = get_user_meta( $author_id, 'credentials', true ) ?: __( 'Financial Content Writer', 'captaincash-blog' );
    $bio         = get_the_author_meta( 'description' );
    $avatar_url  = get_avatar_url( $author_id, [ 'size' => 144 ] );
    $author_page = get_author_posts_url( $author_id );
    $initials    = implode( '', array_map( fn($w) => strtoupper( $w[0] ), explode( ' ', trim( $name ) ) ) );
    ?>
    <div class="author-bio">
        <?php if ( $avatar_url ) : ?>
            <img src="<?php echo esc_url( $avatar_url ); ?>"
                 alt="<?php echo esc_attr( $name ); ?>"
                 class="author-bio-avatar" width="72" height="72" loading="lazy">
        <?php else : ?>
            <div class="author-bio-placeholder" aria-hidden="true"><?php echo esc_html( substr( $initials, 0, 2 ) ); ?></div>
        <?php endif; ?>
        <div class="author-bio-body">
            <div class="author-bio-name"><?php echo esc_html( $name ); ?></div>
            <div class="author-bio-title"><?php echo esc_html( $title ); ?></div>
            <?php if ( $bio ) : ?>
                <div class="author-bio-desc"><?php echo esc_html( $bio ); ?></div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}


// ── Related posts ─────────────────────────────────────────────────
function cc_blog_related_posts( $count = 3 ) {
    if ( ! is_singular( 'post' ) ) return;

    $cats    = wp_get_post_categories( get_the_ID() );
    $related = new WP_Query( [
        'post__not_in'        => [ get_the_ID() ],
        'posts_per_page'      => $count,
        'category__in'        => $cats,
        'ignore_sticky_posts' => 1,
        'orderby'             => 'rand',
    ] );

    if ( ! $related->have_posts() ) return;
    ?>
    <section class="related-posts">
        <h2 class="related-posts-title"><?php _e( 'Related articles', 'captaincash-blog' ); ?></h2>
        <div class="related-grid">
        <?php while ( $related->have_posts() ) : $related->the_post(); ?>
            <a href="<?php the_permalink(); ?>" class="related-card">
                <div class="related-card-thumb">
                    <?php if ( has_post_thumbnail() ) : ?>
                        <?php the_post_thumbnail( 'cc-card', [ 'loading' => 'lazy', 'alt' => esc_attr( get_the_title() ) ] ); ?>
                    <?php endif; ?>
                </div>
                <div class="related-card-body">
                    <?php $cat = get_the_category(); if ( $cat ) : ?>
                        <div class="related-card-cat"><?php echo esc_html( $cat[0]->name ); ?></div>
                    <?php endif; ?>
                    <div class="related-card-title"><?php the_title(); ?></div>
                </div>
            </a>
        <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </section>
    <?php
}


// ── In-content CTA banner shortcode ──────────────────────────────
function cc_blog_cta_shortcode( $atts ) {
    $a = shortcode_atts( [
        'title' => 'Need cash today?',
        'desc'  => 'Get $500–$1,000 by Interac e-Transfer. No credit check. Apply in 5 minutes.',
        'btn'   => 'Claim your cash',
        'url'   => CC_SITE_URL . '/claim-your-cash/',
    ], $atts );

    ob_start(); ?>
    <div class="blog-cta-banner">
        <div class="blog-cta-banner-bg" aria-hidden="true"></div>
        <div class="blog-cta-banner-body">
            <h3><?php echo esc_html( $a['title'] ); ?></h3>
            <p><?php echo esc_html( $a['desc'] ); ?></p>
        </div>
        <a href="<?php echo esc_url( $a['url'] ); ?>" class="blog-cta-banner-btn">
            <?php echo esc_html( $a['btn'] ); ?>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
        </a>
    </div>
    <?php return ob_get_clean();
}
add_shortcode( 'cc_cta', 'cc_blog_cta_shortcode' );


// ── YMYL disclaimer shortcode ──────────────────────────────────────
function cc_blog_ymyl_shortcode( $atts, $content = '' ) {
    $default = 'This article is for informational purposes only and does not constitute financial advice. Approval is subject to eligibility. APR 23%. Borrow responsibly.';
    $text = $content ?: $default;
    ob_start(); ?>
    <div class="ymyl-disclaimer">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <p><?php echo esc_html( $text ); ?></p>
    </div>
    <?php return ob_get_clean();
}
add_shortcode( 'cc_disclaimer', 'cc_blog_ymyl_shortcode' );


// ── Callout box shortcode ─────────────────────────────────────────
function cc_blog_callout_shortcode( $atts, $content = '' ) {
    $a = shortcode_atts( [ 'type' => 'info' ], $atts );
    $type = in_array( $a['type'], [ 'info', 'warning', 'success', 'tip' ] ) ? $a['type'] : 'info';
    return '<div class="callout callout--' . esc_attr( $type ) . '"><p>' . wp_kses_post( $content ) . '</p></div>';
}
add_shortcode( 'callout', 'cc_blog_callout_shortcode' );


// ── Widget area ───────────────────────────────────────────────────
function cc_blog_widgets_init() {
    register_sidebar( [
        'name'          => __( 'Blog Sidebar', 'captaincash-blog' ),
        'id'            => 'blog-sidebar',
        'description'   => __( 'Widgets for the blog sidebar.', 'captaincash-blog' ),
        'before_widget' => '<div class="sb-card sb-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<div class="sb-title">',
        'after_title'   => '</div>',
    ] );
}
add_action( 'widgets_init', 'cc_blog_widgets_init' );


// ── Add custom user fields ────────────────────────────────────────
function cc_blog_author_fields( $user ) {
    ?>
    <h3><?php _e( 'Professional information', 'captaincash-blog' ); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="credentials"><?php _e( 'Title / Credentials', 'captaincash-blog' ); ?></label></th>
            <td>
                <input type="text" name="credentials" id="credentials"
                       value="<?php echo esc_attr( get_user_meta( $user->ID, 'credentials', true ) ); ?>"
                       class="regular-text">
                <p class="description"><?php _e( 'e.g. "Financial Journalist", "CFA", "Senior Content Writer"', 'captaincash-blog' ); ?></p>
            </td>
        </tr>
        <tr>
            <th><label for="linkedin_url"><?php _e( 'LinkedIn URL', 'captaincash-blog' ); ?></label></th>
            <td>
                <input type="url" name="linkedin_url" id="linkedin_url"
                       value="<?php echo esc_url( get_user_meta( $user->ID, 'linkedin_url', true ) ); ?>"
                       class="regular-text">
            </td>
        </tr>
        <tr>
            <th><label for="reviewer_name"><?php _e( 'Fact-checked by', 'captaincash-blog' ); ?></label></th>
            <td>
                <input type="text" name="reviewer_name" id="reviewer_name"
                       value="<?php echo esc_attr( get_user_meta( $user->ID, 'reviewer_name', true ) ); ?>"
                       class="regular-text">
                <p class="description"><?php _e( 'Name of editor/reviewer shown on posts by this author.', 'captaincash-blog' ); ?></p>
            </td>
        </tr>
    </table>
    <?php
}
add_action( 'show_user_profile',   'cc_blog_author_fields' );
add_action( 'edit_user_profile',   'cc_blog_author_fields' );

function cc_blog_save_author_fields( $user_id ) {
    if ( ! current_user_can( 'edit_user', $user_id ) ) return false;
    foreach ( [ 'credentials', 'linkedin_url', 'reviewer_name' ] as $field ) {
        if ( isset( $_POST[ $field ] ) ) {
            update_user_meta( $user_id, $field, sanitize_text_field( $_POST[ $field ] ) );
        }
    }
}
add_action( 'personal_options_update',  'cc_blog_save_author_fields' );
add_action( 'edit_user_profile_update', 'cc_blog_save_author_fields' );


// ── Load schema and social meta ───────────────────────────────────
require_once get_template_directory() . '/inc/schema.php';
require_once get_template_directory() . '/inc/social-meta.php';
require_once get_template_directory() . '/inc/speed.php';


// ── Pagination helper ─────────────────────────────────────────────
function cc_blog_pagination() {
    global $wp_query;
    $big = 999999999;
    echo paginate_links( [
        'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
        'format'    => '?paged=%#%',
        'current'   => max( 1, get_query_var( 'paged' ) ),
        'total'     => $wp_query->max_num_pages,
        'prev_text' => '← ' . __( 'Previous', 'captaincash-blog' ),
        'next_text' => __( 'Next', 'captaincash-blog' ) . ' →',
        'type'      => 'plain',
        'mid_size'  => 2,
    ] );
}
