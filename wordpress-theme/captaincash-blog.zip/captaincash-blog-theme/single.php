<?php
/**
 * Captain Cash Blog — single.php
 * Single post template with:
 * - Dark atmospheric hero
 * - Breadcrumbs
 * - Fact-checked bar
 * - Full entry content
 * - Author bio (E-E-A-T)
 * - Social share
 * - Post tags
 * - Related posts
 * - Sticky sidebar
 */

get_header();

while ( have_posts() ) : the_post();

$cats       = get_the_category();
$cat        = $cats ? $cats[0] : null;
$read_time  = cc_blog_read_time();
$author_id  = get_the_author_meta( 'ID' );
$reviewer   = get_user_meta( $author_id, 'reviewer_name', true );
$credentials = get_user_meta( $author_id, 'credentials', true ) ?: __( 'Financial Content Writer', 'captaincash-blog' );
?>

<!-- Single post hero -->
<div class="single-hero">
  <div class="single-hero-bg" aria-hidden="true">
    <div class="single-hero-orb"></div>
    <div class="single-hero-beam"></div>
    <div class="single-hero-edge"></div>
  </div>
  <div class="container single-hero-inner">

    <?php cc_blog_breadcrumbs(); ?>

    <?php if ( $cat ) : ?>
      <a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>" class="single-cat-badge">
        <?php echo esc_html( $cat->name ); ?>
      </a>
    <?php endif; ?>

    <h1><?php the_title(); ?></h1>

    <div class="single-meta">
      <div class="single-meta-item">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        <a href="<?php echo esc_url( get_author_posts_url( $author_id ) ); ?>">
          <?php the_author(); ?>
        </a>
        <span class="single-meta-sep">·</span>
        <span><?php echo esc_html( $credentials ); ?></span>
      </div>
      <div class="single-meta-item">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
        <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
          <?php echo get_the_date( 'F j, Y' ); ?>
        </time>
      </div>
      <?php if ( get_the_modified_date( 'U' ) > get_the_date( 'U' ) + DAY_IN_SECONDS ) : ?>
      <div class="single-meta-item">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>
        <?php _e( 'Updated', 'captaincash-blog' ); ?>
        <time datetime="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>">
          <?php echo get_the_modified_date( 'F j, Y' ); ?>
        </time>
      </div>
      <?php endif; ?>
      <div class="single-meta-item">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
        <?php echo esc_html( $read_time ); ?>
      </div>
    </div>

  </div>
</div>

<!-- Featured image -->
<?php if ( has_post_thumbnail() ) : ?>
  <div class="single-featured-img">
    <?php the_post_thumbnail( 'cc-featured', [
      'alt'          => esc_attr( get_the_title() ),
      'loading'      => 'eager',
      'fetchpriority'=> 'high',
    ] ); ?>
  </div>
<?php endif; ?>

<!-- Post content + sidebar -->
<div class="single-wrap">
  <div class="container">
    <div class="single-inner">

      <!-- Entry content -->
      <article id="post-<?php the_ID(); ?>" <?php post_class( 'entry-content-wrap' ); ?>>

        <!-- Fact-checked bar -->
        <?php if ( $reviewer ) : ?>
        <div class="fact-checked-bar">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          <p class="fact-checked-text">
            <strong><?php _e( 'Fact-checked', 'captaincash-blog' ); ?>:</strong>
            <?php printf(
              esc_html__( 'Reviewed by %s, Captain Cash editorial team.', 'captaincash-blog' ),
              esc_html( $reviewer )
            ); ?>
            <time datetime="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>">
              <?php echo get_the_modified_date( 'F j, Y' ); ?>
            </time>
          </p>
        </div>
        <?php endif; ?>

        <!-- YMYL disclaimer at top of financial articles -->
        <div class="ymyl-disclaimer">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          <p><?php _e( 'This article is for informational purposes only and does not constitute financial advice. Loan approval is subject to eligibility. APR 23%. Borrow responsibly.', 'captaincash-blog' ); ?></p>
        </div>

        <!-- Post content -->
        <div class="entry-content">
          <?php the_content(); ?>
        </div>

        <!-- Paginated posts navigation -->
        <?php
        wp_link_pages( [
          'before'      => '<nav class="page-links"><span>' . __( 'Pages:', 'captaincash-blog' ) . '</span>',
          'after'       => '</nav>',
          'link_before' => '<span>',
          'link_after'  => '</span>',
        ] );
        ?>

        <!-- Tags -->
        <?php
        $tags = get_the_tags();
        if ( $tags ) :
        ?>
        <div class="post-tags">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color:var(--gray-400)" aria-hidden="true"><path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>
          <?php foreach ( $tags as $tag ) : ?>
            <a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>" class="post-tag">
              <?php echo esc_html( $tag->name ); ?>
            </a>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Social share -->
        <?php cc_blog_social_share(); ?>

        <!-- Author bio (E-E-A-T) -->
        <?php cc_blog_author_bio(); ?>

        <!-- Related posts -->
        <?php cc_blog_related_posts( 3 ); ?>

      </article>

      <!-- Sidebar -->
      <?php get_sidebar(); ?>

    </div><!-- /single-inner -->
  </div><!-- /container -->
</div><!-- /single-wrap -->

<?php
endwhile;
get_footer();
?>
