<?php
/**
 * Captain Cash Blog — page.php
 * Static page template (About, Privacy Policy etc.)
 */
get_header();
while ( have_posts() ) : the_post(); ?>

<div style="background:#000;padding:3rem 0 2.5rem;border-bottom:1px solid rgba(255,255,255,0.06);">
  <div class="container">
    <?php cc_blog_breadcrumbs(); ?>
    <h1 style="font-size:clamp(1.75rem,4vw,2.5rem);font-weight:900;color:#fff;letter-spacing:-0.04em;margin-top:1rem;"><?php the_title(); ?></h1>
  </div>
</div>

<div style="background:#fff;padding:3rem 0 5rem;">
  <div class="container">
    <div style="max-width:780px;">
      <div class="entry-content">
        <?php the_content(); ?>
      </div>
    </div>
  </div>
</div>

<?php endwhile;
get_footer(); ?>
