<?php
/**
 * Captain Cash Blog — 404.php
 */
get_header();
?>
<div class="blog-wrap" style="background:#fff;">
  <div class="container">
    <div class="error-wrap">
      <div class="error-code" aria-hidden="true">404</div>
      <h1 class="error-title"><?php _e( 'Page not found', 'captaincash-blog' ); ?></h1>
      <p class="error-sub"><?php _e( "The article you're looking for may have moved or been removed.", 'captaincash-blog' ); ?></p>
      <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;">
        <a href="<?php echo esc_url( CC_BLOG_URL . '/' ); ?>" class="btn-primary">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>
          <?php _e( 'Back to blog', 'captaincash-blog' ); ?>
        </a>
        <a href="<?php echo esc_url( CC_SITE_URL . '/claim-your-cash/' ); ?>"
           style="display:inline-flex;align-items:center;gap:8px;padding:13px 28px;border:1.5px solid var(--gray-200);border-radius:9999px;font-size:1rem;font-weight:600;color:var(--gray-500);text-decoration:none;transition:all 0.15s;">
          <?php _e( 'Apply for a loan', 'captaincash-blog' ); ?>
        </a>
      </div>
      <div style="margin-top:3rem;max-width:400px;margin-left:auto;margin-right:auto;">
        <?php get_search_form(); ?>
      </div>
    </div>
  </div>
</div>
<?php get_footer(); ?>
