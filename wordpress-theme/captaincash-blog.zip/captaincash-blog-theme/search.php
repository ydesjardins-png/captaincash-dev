<?php
/**
 * Captain Cash Blog — search.php
 */
get_header();
?>
<div class="archive-hero" style="background:#000;border-bottom:1px solid rgba(255,255,255,0.06);">
  <div class="container archive-hero-inner">
    <div class="archive-eyebrow"><?php _e( 'Search results', 'captaincash-blog' ); ?></div>
    <h1 class="archive-title" style="color:#fff;">
      <?php printf( esc_html__( 'Results for: %s', 'captaincash-blog' ), '<span style="color:#e82020">' . esc_html( get_search_query() ) . '</span>' ); ?>
    </h1>
    <?php global $wp_query; if ( $wp_query->found_posts ) : ?>
      <p class="archive-count" style="color:rgba(255,255,255,0.3);margin-top:4px;">
        <?php printf( _n( '%s result', '%s results', $wp_query->found_posts, 'captaincash-blog' ), number_format_i18n( $wp_query->found_posts ) ); ?>
      </p>
    <?php endif; ?>
  </div>
</div>

<div class="blog-wrap">
  <div class="container">
    <div class="blog-inner">
      <main id="main" role="main">

        <!-- Search form -->
        <div style="margin-bottom:2rem;">
          <?php get_search_form(); ?>
        </div>

        <?php if ( have_posts() ) : ?>
          <div class="post-grid">
            <?php while ( have_posts() ) : the_post();
              $cats = get_the_category(); $cat = $cats ? $cats[0] : null;
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
              <div class="post-card-thumb">
                <?php if ( has_post_thumbnail() ) : ?>
                  <a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
                    <?php the_post_thumbnail( 'cc-card', [ 'loading' => 'lazy', 'alt' => '' ] ); ?>
                  </a>
                <?php else : ?>
                  <a href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1"><div class="post-card-thumb-placeholder"></div></a>
                <?php endif; ?>
              </div>
              <div class="post-card-body">
                <div class="post-card-meta">
                  <?php if ( $cat ) : ?><a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>" class="post-card-cat"><?php echo esc_html( $cat->name ); ?></a><?php endif; ?>
                  <span class="post-card-date"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo get_the_date( 'M j, Y' ); ?></time></span>
                </div>
                <a href="<?php the_permalink(); ?>" class="post-card-title"><?php the_title(); ?></a>
                <p class="post-card-excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>
                <div class="post-card-footer">
                  <div class="post-card-author"><span class="post-card-author-name"><?php the_author(); ?></span></div>
                  <a href="<?php the_permalink(); ?>" class="post-card-read-link"><?php _e( 'Read', 'captaincash-blog' ); ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
                </div>
              </div>
            </article>
            <?php endwhile; ?>
          </div>
          <div class="blog-pagination"><?php cc_blog_pagination(); ?></div>
        <?php else : ?>
          <p style="color:var(--gray-500);padding:3rem 0;"><?php printf( esc_html__( 'No results for "%s". Try different keywords.', 'captaincash-blog' ), esc_html( get_search_query() ) ); ?></p>
        <?php endif; ?>

      </main>
      <?php get_sidebar(); ?>
    </div>
  </div>
</div>
<?php get_footer(); ?>
