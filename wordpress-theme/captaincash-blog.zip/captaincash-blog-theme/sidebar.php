<?php
/**
 * Captain Cash Blog — sidebar.php
 * Sticky sidebar with: CTA card, categories, recent posts
 */
?>
<aside class="blog-sidebar" role="complementary" aria-label="<?php esc_attr_e( 'Blog sidebar', 'captaincash-blog' ); ?>">

  <!-- CTA card — dark, branded -->
  <div class="sb-card sb-card--dark">
    <div class="sb-cta-amount">$500–$1,000</div>
    <p class="sb-cta-sub"><?php _e( 'Same-day Interac e-Transfer. No credit check. Apply in 5 minutes.', 'captaincash-blog' ); ?></p>
    <a href="<?php echo esc_url( CC_SITE_URL . '/claim-your-cash/' ); ?>" class="sb-cta-btn">
      <?php _e( 'Claim your cash', 'captaincash-blog' ); ?>
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
    </a>
    <ul class="sb-cta-features">
      <li>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>
        <?php _e( 'No credit check', 'captaincash-blog' ); ?>
      </li>
      <li>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>
        <?php _e( 'APR 23% — fully transparent', 'captaincash-blog' ); ?>
      </li>
      <li>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>
        <?php _e( 'Trusted since 2015', 'captaincash-blog' ); ?>
      </li>
    </ul>
  </div>

  <!-- Categories -->
  <?php
  $categories = get_categories( [ 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC' ] );
  if ( $categories ) :
  ?>
  <div class="sb-card">
    <div class="sb-title"><?php _e( 'Browse by topic', 'captaincash-blog' ); ?></div>
    <nav class="sb-cat-list" aria-label="<?php esc_attr_e( 'Blog categories', 'captaincash-blog' ); ?>">
      <?php foreach ( $categories as $cat ) : ?>
        <a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>" class="sb-cat-item">
          <?php echo esc_html( $cat->name ); ?>
          <span class="sb-cat-count"><?php echo esc_html( $cat->count ); ?></span>
        </a>
      <?php endforeach; ?>
    </nav>
  </div>
  <?php endif; ?>

  <!-- Recent posts -->
  <?php
  $recent = new WP_Query( [
    'posts_per_page'      => 5,
    'ignore_sticky_posts' => 1,
    'post__not_in'        => is_singular() ? [ get_the_ID() ] : [],
  ] );
  if ( $recent->have_posts() ) :
  ?>
  <div class="sb-card">
    <div class="sb-title"><?php _e( 'Recent articles', 'captaincash-blog' ); ?></div>
    <div class="sb-recent-list">
      <?php while ( $recent->have_posts() ) : $recent->the_post(); ?>
        <a href="<?php the_permalink(); ?>" class="sb-recent-item">
          <div class="sb-recent-thumb">
            <?php if ( has_post_thumbnail() ) : ?>
              <?php the_post_thumbnail( 'cc-thumb', [ 'loading' => 'lazy', 'alt' => esc_attr( get_the_title() ) ] ); ?>
            <?php else : ?>
              <div style="width:100%;height:100%;background:#0b1a33;"></div>
            <?php endif; ?>
          </div>
          <div>
            <div class="sb-recent-title"><?php the_title(); ?></div>
            <div class="sb-recent-date"><?php echo get_the_date( 'M j, Y' ); ?></div>
          </div>
        </a>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
  </div>
  <?php endif; ?>

  <!-- Optional: registered widget area -->
  <?php if ( is_active_sidebar( 'blog-sidebar' ) ) : ?>
    <?php dynamic_sidebar( 'blog-sidebar' ); ?>
  <?php endif; ?>

</aside>
