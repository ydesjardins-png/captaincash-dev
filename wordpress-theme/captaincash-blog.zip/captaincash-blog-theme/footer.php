<?php
/**
 * Captain Cash Blog — footer.php
 * Matches captaincash.ca footer exactly
 */
?>

<footer class="site-footer site-footer--dark">
  <div class="footer-bg" aria-hidden="true">
    <div class="footer-orb-1"></div>
    <div class="footer-orb-2"></div>
    <div class="footer-beam"></div>
    <div class="footer-edge"></div>
  </div>
  <div class="container">
    <div class="footer-grid">
      <div class="footer-brand">
        <a href="<?php echo esc_url( CC_SITE_URL ); ?>" class="site-logo-img site-logo-img--footer">
          <img src="<?php echo esc_url( CC_SITE_URL ); ?>/images/mascot/sprites/logo-lockup-small.webp" alt="Captain Cash" width="140" height="35" loading="lazy">
        </a>
        <p style="margin-top:1rem;color:var(--gray-400);font-size:0.875rem;line-height:1.7">A fast, fair alternative to payday loans for Canadians who need cash today. Serving Canada since 2015.</p>
        <address style="margin-top:1rem;font-size:0.8rem;color:var(--gray-500);font-style:normal;line-height:1.7">
          1701 Hollis Street W. Suite 800<br>
          Halifax, NS B3J 2T9<br>
          <a href="tel:18882261026" style="color:var(--gray-400)">1-888-226-1026</a>
        </address>
      </div>
      <div class="footer-col">
        <h4>Products</h4>
        <ul>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/loans-in-canada/">Loans in Canada</a></li>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/payday-loans/">Payday loans</a></li>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/bad-credit-loans-canada/">Bad credit loans</a></li>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/installment-loans-canada/">Instalment loans</a></li>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/no-credit-check-loans-canada/">No credit check</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Company</h4>
        <ul>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/about-us/">About us</a></li>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/testimonials/">Reviews</a></li>
          <li><a href="/blog/">Blog</a></li>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/terms-conditions/">Terms and conditions</a></li>
            <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/privacy-policy/">Privacy policy</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Support</h4>
        <ul>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/how-does-it-work/">How it works</a></li>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/support/">FAQ</a></li>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/online-payment/">Online payment</a></li>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/contact-us/">Contact us</a></li>
          <li><a href="<?php echo esc_url( CC_SITE_URL ); ?>/renew-your-loan/">Renew your loan</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <p>Captain Cash &copy; 2026, a division of Opal Financial. All Rights Reserved.</p>
      <p>APR 23% &mdash; <a href="<?php echo esc_url( CC_SITE_URL ); ?>/privacy-policy/" style="color:var(--gray-500)">Privacy Policy</a> &mdash; Borrow responsibly</p>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
